document.addEventListener("DOMContentLoaded", function () {
    const catalogo = [
        { id: 1, imagen: src="cocacola.jpg", precio: 20, descripcion: "Coca-Cola 600ml"},
        { id: 2, imagen: src="sprite.jpg", precio: 19, descripcion: "Sprite 600ml"},
        { id: 3, imagen: src="fresca.jpg", precio: 19, descripcion:"Fresca 600ml"},
        { id: 4, imagen: src="fantafresa.jpg", precio: 19, descripcion:"Fanta sabor fresa 600ml"},
        { id: 5, imagen: src="fantanaranja.jpg", precio: 19, descripcion:"Fanta sabor naranja 600ml"},
        // Agrega más productos aquí
    ];
    const catalogoContainer = document.getElementById("catalogo");
    const resumenCompra = document.getElementById("resumenCompra");
    const total = document.getElementById("total");

    // Genera las tarjetas de productos en el catálogo
    catalogo.forEach((producto) => {
        const card = document.createElement("div");
        card.classList.add("col-md-4", "mb-4");
        card.innerHTML = `
            <div class="card">
                <img src="${producto.imagen}" class="card-img-top" alt="Producto ${producto.id}">
                <div class="card-body">
                    <h5 class="card-title">Producto: ${producto.id}</h5>
                    <p class="card-text">${producto.descripcion} <br> Precio: $${producto.precio}<br> Cantidad de Producto: 
                    <input id="cantidadProducto${producto.id}" type="number" value="1" min="1"></p>
                    <button class="btn btn-primary">Agregar al Carrito</button>
                </div>
            </div>
        `;
        catalogoContainer.appendChild(card);

        // Agrega un evento de clic al botón de "Agregar al Carrito"
        const botonAgregar = card.querySelector("button");
        botonAgregar.addEventListener("click", function () {
            const cantidad = parseInt(document.getElementById(`cantidadProducto${producto.id}`).value);

            if (cantidad > 0) {
                agregarProductoAlCarrito(producto, cantidad);
            }
        });
    });

    const carrito = [];

    function agregarProductoAlCarrito(producto, cantidad) {
        // Busca si el producto ya está en el carrito
        const productoEnCarrito = carrito.find((item) => item.producto.id === producto.id);

        if (productoEnCarrito) {
            // Si ya está en el carrito, actualiza la cantidad
            productoEnCarrito.cantidad += cantidad;
        } else {
            // Si no está en el carrito, agrega un nuevo elemento al carrito
            carrito.push({ producto, cantidad });
        }

        // Actualiza el resumen de la compra
        actualizarResumenCompra();
    }

    function actualizarResumenCompra() {
        // Limpia el resumen de compra
        resumenCompra.innerHTML = `
        `;
        let subtotalTotal = 0;

        carrito.forEach((item) => {
            const fila = document.createElement("tr");
            fila.innerHTML = `
            <td>Producto ${item.producto.id}</td>
            <td>${item.producto.descripcion}</td>
            <td>${item.cantidad}</td>
            <td>${item.producto.precio}</td>
            <td>$${item.producto.precio * item.cantidad}</td>
            `;
            resumenCompra.appendChild(fila);

            subtotalTotal += item.producto.precio * item.cantidad;
        });

        // Actualiza el total
        total.textContent = `$${subtotalTotal}`;
    }

    const finalizarCompra = document.getElementById("finalizarCompra")
    finalizarCompra.addEventListener("click",function (){
        localStorage.setItem("carrito", JSON.stringify(carrito));
            // Redirige a la página "Ticket.html"
            window.location.href = "Ticket.html";
    });
});